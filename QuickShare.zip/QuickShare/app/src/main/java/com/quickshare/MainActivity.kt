package com.quickshare

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: ShareViewModel by viewModels()

    private fun requiredPermissions(): Array<String> {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_ADVERTISE
            p += Manifest.permission.BLUETOOTH_CONNECT
            p += Manifest.permission.BLUETOOTH_SCAN
        } else {
            p += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.NEARBY_WIFI_DEVICES
        return p.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun App() {
        var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

        val permLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { res ->
            if (res.values.all { it }) pendingAction?.invoke()
            else vm.status = "Permissions are required"
            pendingAction = null
        }
        val filePicker = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenMultipleDocuments()
        ) { uris -> if (uris.isNotEmpty()) vm.sendFiles(uris) }

        fun withPermissions(action: () -> Unit) {
            pendingAction = action
            permLauncher.launch(requiredPermissions())
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("QuickShare") },
                    actions = { if (vm.role != null) TextButton({ vm.reset() }) { Text("Stop") } }
                )
            }
        ) { pad ->
            Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
                Text(vm.status, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(16.dp))

                when {
                    vm.role == null -> Home(
                        onSend = { withPermissions { vm.startSending() } },
                        onReceive = { withPermissions { vm.startReceiving() } }
                    )
                    vm.connectedName != null -> Connected(
                        onPick = { filePicker.launch(arrayOf("*/*")) }
                    )
                    vm.role == Role.SENDER -> Nearby()
                    else -> Box(Modifier.fillMaxWidth(), Alignment.Center) { CircularProgressIndicator() }
                }
            }
        }

        vm.pending?.let { p ->
            AlertDialog(
                onDismissRequest = { vm.rejectPending() },
                title = { Text("Connect with ${p.name}?") },
                text = { Text("Make sure this code matches on both phones:\n\n${p.digits}") },
                confirmButton = { TextButton({ vm.acceptPending() }) { Text("Accept") } },
                dismissButton = { TextButton({ vm.rejectPending() }) { Text("Reject") } }
            )
        }
    }

    @Composable
    private fun Home(onSend: () -> Unit, onReceive: () -> Unit) {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Button(onSend, Modifier.fillMaxWidth().height(80.dp)) { Text("Send", style = MaterialTheme.typography.titleLarge) }
            Spacer(Modifier.height(16.dp))
            FilledTonalButton(onReceive, Modifier.fillMaxWidth().height(80.dp)) { Text("Receive", style = MaterialTheme.typography.titleLarge) }
        }
    }

    @Composable
    private fun Nearby() {
        if (vm.endpoints.isEmpty()) {
            Box(Modifier.fillMaxWidth(), Alignment.Center) { CircularProgressIndicator() }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.endpoints, key = { it.id }) { e ->
                Card(onClick = { vm.connect(e) }, Modifier.fillMaxWidth()) {
                    Text(e.name, Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }

    @Composable
    private fun Connected(onPick: () -> Unit) {
        Text("Connected to ${vm.connectedName}", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        if (vm.role == Role.SENDER) {
            Button(onPick, Modifier.fillMaxWidth()) { Text("Choose files to send") }
            Spacer(Modifier.height(12.dp))
        } else {
            Text("Files save to Downloads/QuickShare", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(12.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.transfers.values.sortedByDescending { it.startedAt }, key = { it.id }) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text((if (t.outgoing) "↑ " else "↓ ") + t.name, maxLines = 1)
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(progress = { t.progress }, Modifier.fillMaxWidth())
                        Spacer(Modifier.height(4.dp))
                        Text(
                            when {
                                t.failed -> "Failed"
                                t.finished -> "Done"
                                else -> "%.0f%% • %.1f MB/s".format(t.progress * 100, t.mbPerSec)
                            },
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
