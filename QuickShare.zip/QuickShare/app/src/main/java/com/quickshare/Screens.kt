package com.quickshare

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

private enum class Screen { HOME, SEARCH, WAITING, CONNECTED }

// ───────────────────────── helpers ─────────────────────────

fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 KB"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1 -> "%.2f GB".format(gb)
        mb >= 1 -> "%.1f MB".format(mb)
        else -> "%.0f KB".format(kb)
    }
}

private val tilePalette = listOf(
    Color(0xFF2563EB), Color(0xFF0891B2), Color(0xFF7C3AED),
    Color(0xFFDB2777), Color(0xFFEA580C), Color(0xFF16A34A)
)

// ───────────────────────── root ─────────────────────────

@Composable
fun QuickShareApp(vm: ShareViewModel, perms: Array<String>) {
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res ->
        if (res.values.all { it }) pendingAction?.invoke()
        else vm.status = "Permissions are required to find nearby phones"
        pendingAction = null
    }
    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) vm.sendFiles(uris) }

    fun withPermissions(action: () -> Unit) {
        pendingAction = action
        permLauncher.launch(perms)
    }

    val screen = when {
        vm.role == null -> Screen.HOME
        vm.connectedName != null -> Screen.CONNECTED
        vm.role == Role.SENDER -> Screen.SEARCH
        else -> Screen.WAITING
    }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(showClose = screen != Screen.HOME, onClose = { vm.reset() })

        Crossfade(screen, Modifier.weight(1f), label = "screen") { s ->
            when (s) {
                Screen.HOME -> HomeScreen(
                    status = vm.status,
                    onSend = { withPermissions { vm.startSending() } },
                    onReceive = { withPermissions { vm.startReceiving() } }
                )
                Screen.SEARCH -> SearchScreen(vm)
                Screen.WAITING -> WaitingScreen(vm)
                Screen.CONNECTED -> ConnectedScreen(vm, onPick = { filePicker.launch(arrayOf("*/*")) })
            }
        }
    }

    vm.pending?.let { p ->
        AlertDialog(
            onDismissRequest = { vm.rejectPending() },
            shape = RoundedCornerShape(24.dp),
            title = { Text("Connect with ${p.name}?", fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Check that this code is the same on both phones",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    Box(
                        Modifier.clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(horizontal = 28.dp, vertical = 14.dp)
                    ) {
                        Text(
                            p.digits,
                            fontSize = 34.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 6.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            },
            confirmButton = { Button({ vm.acceptPending() }) { Text("Accept") } },
            dismissButton = { TextButton({ vm.rejectPending() }) { Text("Reject") } }
        )
    }
}

// ───────────────────────── shared pieces ─────────────────────────

@Composable
private fun AppLogo(size: Int = 44, corner: Int = 14) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(corner.dp)).background(BrandGradient),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painterResource(R.drawable.ic_launcher_foreground),
            contentDescription = null,
            modifier = Modifier.requiredSize((size * 1.6f).dp)
        )
    }
}

@Composable
private fun TopBar(showClose: Boolean, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppLogo(36, 11)
        Spacer(Modifier.width(10.dp))
        Text("QuickShare", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (showClose) {
            IconButton(
                onClose,
                Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
            ) { Icon(Icons.Default.Close, contentDescription = "Stop", Modifier.size(20.dp)) }
        }
    }
}

@Composable
private fun StatusLine(text: String) {
    val isError = text.startsWith("Error") || text.startsWith("Permissions") ||
        text.contains("failed", ignoreCase = true)
    if (isError) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.errorContainer).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
        }
    } else {
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun RadarPulse(label: String) {
    val transition = rememberInfiniteTransition(label = "radar")
    val p by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse"
    )
    val color = MaterialTheme.colorScheme.primary
    Box(Modifier.size(230.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            for (i in 0..2) {
                val q = (p + i / 3f) % 1f
                drawCircle(
                    color = color.copy(alpha = (1f - q) * 0.35f),
                    radius = size.minDimension / 2f * q,
                    style = Stroke(width = 3.dp.toPx())
                )
            }
        }
        Box(
            Modifier.size(76.dp).clip(CircleShape).background(BrandGradient),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Phone, label, tint = Color.White, modifier = Modifier.size(34.dp)) }
    }
}

// ───────────────────────── home ─────────────────────────

@Composable
private fun HomeScreen(status: String, onSend: () -> Unit, onReceive: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        AppLogo(96, 28)
        Spacer(Modifier.height(20.dp))
        Text("Share files, instantly", fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            "Send any file to a nearby phone at full speed. No internet, no data used.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(32.dp))

        // Send
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(BrandGradient)
                .clickable(onClick = onSend).padding(22.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Send, null, tint = Color.White) }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text("Send", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Pick files and find a phone", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                }
                Icon(Icons.Default.ArrowForward, null, tint = Color.White)
            }
        }

        Spacer(Modifier.height(14.dp))

        // Receive
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surface)
                .clickable(onClick = onReceive).padding(22.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.ArrowForward, null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.rotate(90f)
                    )
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text("Receive", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Make this phone visible",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp
                    )
                }
                Icon(Icons.Default.ArrowForward, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(Modifier.height(24.dp))
        if (status != "Ready") StatusLine(status)

        Spacer(Modifier.weight(1f))
        Text(
            "Keep Bluetooth, Wi-Fi and Location turned on",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 20.dp)
        )
    }
}

// ───────────────────────── search / waiting ─────────────────────────

@Composable
private fun SearchScreen(vm: ShareViewModel) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Spacer(Modifier.height(8.dp)) }
        item { RadarPulse("Searching") }
        item {
            Text("Searching nearby…", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        item { StatusLine(if (vm.endpoints.isEmpty()) "Ask the other person to tap Receive" else "Tap a phone to connect") }
        item { Spacer(Modifier.height(6.dp)) }
        items(vm.endpoints, key = { it.id }) { e ->
            Card(
                onClick = { vm.connect(e) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).clip(CircleShape).background(BrandGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            e.name.take(1).uppercase(), color = Color.White,
                            fontWeight = FontWeight.Bold, fontSize = 18.sp
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Tap to connect", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Icon(Icons.Default.ArrowForward, null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun WaitingScreen(vm: ShareViewModel) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        RadarPulse("Waiting")
        Spacer(Modifier.height(16.dp))
        Text("Ready to receive", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Visible to nearby phones as",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primaryContainer)
                .padding(horizontal = 18.dp, vertical = 8.dp)
        ) {
            Text(vm.myName, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Spacer(Modifier.height(20.dp))
        if (vm.status != "Waiting for a sender…") StatusLine(vm.status)
    }
}

// ───────────────────────── connected ─────────────────────────

@Composable
private fun ConnectedScreen(vm: ShareViewModel, onPick: () -> Unit) {
    val list = vm.transfers.values.sortedByDescending { it.startedAt }
    val isSender = vm.role == Role.SENDER

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(BrandGradient), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Phone, null, tint = Color.White)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        vm.connectedName ?: "", fontWeight = FontWeight.Bold, fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(BrandGreen))
                        Spacer(Modifier.width(6.dp))
                        Text("Connected", fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
                TextButton({ vm.reset() }) { Text("Disconnect") }
            }
        }

        item {
            if (isSender) {
                Button(
                    onPick,
                    Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Send, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Choose files to send", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            } else {
                Text(
                    "Incoming files are saved to Downloads/QuickShare",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
        }

        item {
            Text(
                "Transfers", fontWeight = FontWeight.Bold, fontSize = 16.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        if (list.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                    Text(
                        if (isSender) "No files sent yet" else "Waiting for files…",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(list, key = { it.id }) { TransferRow(it) }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun TransferRow(t: Transfer) {
    val ext = t.name.substringAfterLast('.', "").uppercase().take(4).ifEmpty { "FILE" }
    val tint = remember(ext) { tilePalette[abs(ext.hashCode()) % tilePalette.size] }
    val active = !t.finished && !t.failed

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)).background(tint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(ext, color = tint, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(t.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(2.dp))
                val sub = when {
                    t.failed -> "Failed"
                    t.finished -> (if (t.outgoing) "Sent" else "Received") + " • " + formatSize(t.total)
                    t.total > 0 -> "${formatSize(t.done)} of ${formatSize(t.total)} • %.1f MB/s".format(t.mbPerSec)
                    else -> "Starting…"
                }
                Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (active) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { t.progress },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            when {
                t.failed -> Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error)
                t.finished -> Icon(Icons.Default.CheckCircle, null, tint = BrandGreen)
                t.outgoing -> Icon(Icons.Default.Send, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                else -> Icon(
                    Icons.Default.ArrowForward, null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp).rotate(90f)
                )
            }
        }
    }
}
