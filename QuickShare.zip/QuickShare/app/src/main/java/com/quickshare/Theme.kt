package com.quickshare

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val BrandBlue = Color(0xFF2563EB)
val BrandCyan = Color(0xFF06B6D4)
val BrandGreen = Color(0xFF16A34A)
val BrandGradient = Brush.linearGradient(listOf(BrandBlue, BrandCyan))

private val LightColors = lightColorScheme(
    primary = BrandBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBE7FF),
    onPrimaryContainer = Color(0xFF0B1F4D),
    secondary = Color(0xFF0891B2),
    secondaryContainer = Color(0xFFD0F3FA),
    onSecondaryContainer = Color(0xFF053541),
    background = Color(0xFFF4F7FC),
    onBackground = Color(0xFF0E1117),
    surface = Color.White,
    onSurface = Color(0xFF0E1117),
    surfaceVariant = Color(0xFFE8EDF6),
    onSurfaceVariant = Color(0xFF4B5565),
    error = Color(0xFFDC2626),
    errorContainer = Color(0xFFFDE2E2),
    onErrorContainer = Color(0xFF5A0B0B)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7BA6FF),
    onPrimary = Color(0xFF0A2A6B),
    primaryContainer = Color(0xFF1D3F8F),
    onPrimaryContainer = Color(0xFFDBE7FF),
    secondary = Color(0xFF4DD4EC),
    secondaryContainer = Color(0xFF0B4B59),
    onSecondaryContainer = Color(0xFFD0F3FA),
    background = Color(0xFF0E1117),
    onBackground = Color(0xFFE6EAF2),
    surface = Color(0xFF161B24),
    onSurface = Color(0xFFE6EAF2),
    surfaceVariant = Color(0xFF222A36),
    onSurfaceVariant = Color(0xFFA9B4C4),
    error = Color(0xFFFF8A8A),
    errorContainer = Color(0xFF5A1A1A),
    onErrorContainer = Color(0xFFFFDADA)
)

@Composable
fun QuickShareTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
