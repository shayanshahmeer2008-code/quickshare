package com.quickshare

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*

enum class Role { SENDER, RECEIVER }

data class Endpoint(val id: String, val name: String)
data class PendingConn(val id: String, val name: String, val digits: String)
data class Transfer(
    val id: Long,
    val name: String,
    val total: Long,
    val done: Long = 0,
    val outgoing: Boolean,
    val startedAt: Long = SystemClock.elapsedRealtime(),
    val finished: Boolean = false,
    val failed: Boolean = false
) {
    val progress: Float get() = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
    val mbPerSec: Float
        get() {
            val sec = (SystemClock.elapsedRealtime() - startedAt) / 1000f
            return if (sec > 0.2f) done / 1_048_576f / sec else 0f
        }
}

class ShareViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val client = Nearby.getConnectionsClient(ctx)
    private val serviceId = "com.quickshare.SERVICE"
    val myName = Build.MODEL ?: "Android"
    private val strategy = Strategy.P2P_POINT_TO_POINT

    var role by mutableStateOf<Role?>(null)
    var status by mutableStateOf("Ready")
    var pending by mutableStateOf<PendingConn?>(null)
    var connectedName by mutableStateOf<String?>(null)
    private var connectedId: String? = null

    val endpoints = mutableStateListOf<Endpoint>()
    val transfers = mutableStateMapOf<Long, Transfer>()

    private val incomingNames = mutableMapOf<Long, String>()
    private val incomingFiles = mutableMapOf<Long, Payload>()

    // ---------- Start / stop ----------

    fun startReceiving() {
        reset()
        role = Role.RECEIVER
        status = "Waiting for a sender…"
        client.startAdvertising(
            myName, serviceId, lifecycle,
            AdvertisingOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { status = "Error: ${it.message}" }
    }

    fun startSending() {
        reset()
        role = Role.SENDER
        status = "Looking for nearby phones…"
        client.startDiscovery(
            serviceId, discovery,
            DiscoveryOptions.Builder().setStrategy(strategy).build()
        ).addOnFailureListener { status = "Error: ${it.message}" }
    }

    fun connect(e: Endpoint) {
        status = "Connecting to ${e.name}…"
        client.requestConnection(myName, e.id, lifecycle)
            .addOnFailureListener { status = "Error: ${it.message}" }
    }

    fun acceptPending() {
        pending?.let { client.acceptConnection(it.id, payloadCallback) }
        pending = null
    }

    fun rejectPending() {
        pending?.let { client.rejectConnection(it.id) }
        pending = null
        status = "Connection rejected"
    }

    fun reset() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        endpoints.clear()
        transfers.clear()
        incomingNames.clear()
        incomingFiles.clear()
        pending = null
        connectedName = null
        connectedId = null
        role = null
        status = "Ready"
    }

    override fun onCleared() {
        client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints()
    }

    // ---------- Sending ----------

    fun sendFiles(uris: List<Uri>) {
        val target = connectedId ?: return
        for (uri in uris) {
            val (name, size) = queryNameSize(uri)
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: continue
            val payload = Payload.fromFile(pfd)
            transfers[payload.id] = Transfer(payload.id, name, size, outgoing = true)
            // name first, then the file itself
            client.sendPayload(target, Payload.fromBytes("${payload.id}|$name".toByteArray()))
            client.sendPayload(target, payload)
        }
    }

    private fun queryNameSize(uri: Uri): Pair<String, Long> {
        var name = "file_${System.currentTimeMillis()}"
        var size = 0L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (n >= 0) name = c.getString(n)
                if (s >= 0) size = c.getLong(s)
            }
        }
        return name to size
    }

    // ---------- Callbacks ----------

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            if (endpoints.none { it.id == id }) endpoints.add(Endpoint(id, info.endpointName))
        }
        override fun onEndpointLost(id: String) { endpoints.removeAll { it.id == id } }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            pending = PendingConn(id, info.endpointName, info.authenticationDigits)
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                connectedId = id
                connectedName = endpoints.firstOrNull { it.id == id }?.name ?: "Device"
                status = "Connected"
                client.stopAdvertising()
                client.stopDiscovery()
            } else {
                status = "Connection failed"
            }
        }

        override fun onDisconnected(id: String) {
            connectedId = null
            connectedName = null
            status = "Disconnected"
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> {
                    val text = String(payload.asBytes() ?: return)
                    val i = text.indexOf('|')
                    if (i > 0) text.substring(0, i).toLongOrNull()?.let {
                        incomingNames[it] = text.substring(i + 1)
                    }
                }
                Payload.Type.FILE -> {
                    incomingFiles[payload.id] = payload
                    val name = incomingNames[payload.id] ?: "file_${payload.id}"
                    transfers[payload.id] = Transfer(payload.id, name, 0, outgoing = false)
                }
                else -> {}
            }
        }

        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {
            val t = transfers[u.payloadId] ?: return
            val name = incomingNames[u.payloadId] ?: t.name
            when (u.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS ->
                    transfers[u.payloadId] = t.copy(name = name, done = u.bytesTransferred, total = u.totalBytes)
                PayloadTransferUpdate.Status.SUCCESS -> {
                    transfers[u.payloadId] = t.copy(name = name, done = u.totalBytes, total = u.totalBytes, finished = true)
                    if (!t.outgoing) incomingFiles.remove(u.payloadId)?.let { saveReceived(it, name) }
                }
                PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED ->
                    transfers[u.payloadId] = t.copy(failed = true)
            }
        }
    }

    // ---------- Save to Downloads/QuickShare ----------

    private fun saveReceived(payload: Payload, name: String) {
        val file = payload.asFile() ?: return
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/QuickShare")
        }
        val dest = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
        try {
            val input = file.asUri()?.let { ctx.contentResolver.openInputStream(it) }
                ?: file.asJavaFile()?.inputStream() ?: return
            input.use { i -> ctx.contentResolver.openOutputStream(dest)?.use { o -> i.copyTo(o, 1 shl 16) } }
            file.asJavaFile()?.delete()
        } catch (e: Exception) {
            status = "Save failed: ${e.message}"
        }
    }
}
